//
//  ViewController.m
//  TempExample
//
//  Created by ZJ on 9/7/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ViewController.h"
#import "ZJBLETool.h"
#import "HYConnectTableViewController.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, weak) HYPeripheralManager *bleManager;

@end

static NSString *TitleCell = @"cell";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initSettiing];
}

- (void)initSettiing {
    self.title = @"蓝牙列表";
    self.tableView.tableFooterView = [UIView new];
    
    self.bleManager = [HYPeripheralManager shareManagerDidUpdateStateHandle:^(HYPeripheralManagerState state) {
        NSLog(@"state = %zd", state);
    }];
    [[HYPeripheralManager shareManager] scanPeripheralWithServiceUUIDs:nil completion:^(id obj) {
        if (obj) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];    // resetting 不回调了
            });
        }
    }];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"count0 = %zd", self.bleManager.discoveredPeripherals.count);

    return self.bleManager.discoveredPeripherals.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TitleCell];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:TitleCell];
    }

    NSLog(@"count1 = %zd", self.bleManager.discoveredPeripherals.count);

    HYPeripheral *device = self.bleManager.discoveredPeripherals[indexPath.row];
    
    cell.textLabel.text = device.peripheral.name;
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        HYConnectTableViewController *vc = [[HYConnectTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
        vc.peripheral = self.bleManager.discoveredPeripherals[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"已发现";
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//    [self.bleManager refreshDiscoverPeripheral];  // 该方法不安全
}
//

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self.tableView reloadData];
}

- (void)dealloc {
    NSLog(@"%s", __func__);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
