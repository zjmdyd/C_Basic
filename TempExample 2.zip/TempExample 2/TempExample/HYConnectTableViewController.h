//
//  HYConnectTableViewController.h
//  TempExample
//
//  Created by ZJ on 9/13/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJBLETool.h"

@interface HYConnectTableViewController : UITableViewController

@property (nonatomic, strong) HYPeripheral *peripheral;

@end
