//
//  HYConnectTableViewController.m
//  TempExample
//
//  Created by ZJ on 9/13/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "HYConnectTableViewController.h"

@interface HYConnectTableViewController () {
    NSArray *_cellTitles;
    NSMutableArray *_values;
}

@property (nonatomic, weak) HYPeripheralManager *bleManager;

@end

static NSString *TitleCell = @"cell2";

@implementation HYConnectTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initAry];
    [self initSettiing];
}

- (void)initAry {
    _cellTitles = @[@"电池", @"体温", @"SNCode"];
    _values = @[@"...", @"...", @"..."].mutableCopy;
}

- (void)initSettiing {
    self.title = self.peripheral.name?:@"未命名";
    self.bleManager = [HYPeripheralManager shareManager];
    
    [self connectPeripheral:self.peripheral];
}

- (void)connectPeripheral:(HYPeripheral *)peripheral {
    self.title = @"连接中...";
    
    [self.bleManager connectPeripheral:peripheral completion:^(HYPeripheral *obj, NSError *connectError, NSError *serviceException) {
        NSLog(@"connectError = %@, %@", connectError, serviceException);

        dispatch_async(dispatch_get_main_queue(), ^{
            if (connectError) {
                self.title = @"连接失败";
            }else {
                self.title = self.peripheral.name?:@"未命名";
                
                [self.bleManager readBatteryData:peripheral completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                    [self refreshValue:value atIndex:0];
                }];
                [self.bleManager readTemperatureData:peripheral completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                    [self refreshValue:value atIndex:1];
                }];
                [self.bleManager readSNCodeData:peripheral completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                    [self refreshValue:value atIndex:2];
                }];
            }
        });
    }];
}

- (void)refreshValue:(NSString *)value atIndex:(NSUInteger)index {
    if (value) {
        if (index < _values.count) {
            [_values replaceObjectAtIndex:index withObject:value];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _cellTitles.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TitleCell];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:TitleCell];
    }
    cell.textLabel.text = _values[indexPath.section];
    
    return cell;
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return _cellTitles[section];
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 38;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return FLT_EPSILON;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
