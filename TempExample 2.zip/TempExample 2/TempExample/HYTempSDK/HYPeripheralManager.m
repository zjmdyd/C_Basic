//
//  HYPeripheralManager.m
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "HYPeripheralManager.h"
#import "HYPeripheral.h"
#import <CommonCrypto/CommonDigest.h>
#import <UIKit/UIKit.h>

@interface HYPeripheralManager ()<CBCentralManagerDelegate> {
    BOOL _isRefreshing;         // 扫描设备
    BOOL _isManualDisconnect;   // 手动断开设备
    HYPeripheral *_disconnectPeripheral;
    NSArray *_searchUUIDs;
}

@property (nonatomic, strong) CBCentralManager *centralManager;
@property (nonatomic, strong) PeripheralScanCompletionHandle scanCompletion;
@property (nonatomic, strong) PeripheralStateUpdateHandle stateCompletion;
@property (nonatomic, strong) PeripheralConnectCompletionHandle connectCompletion;
@property (nonatomic, strong) PeripheralConnectCompletionHandle disConnectCompletion;

/**
 *  设备断开之后是否自动执行搜索,默认为YES
 */
@property (nonatomic, getter=isAutomScan) BOOL automScan;

@end

#define RefreshTimeSpan 15
#define MinPower 2800       // 低电量提醒

static HYPeripheralManager *_manager = nil;

@implementation HYPeripheralManager

@synthesize state = _state;

+ (instancetype)shareManager {
    if (!_manager) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _manager = [[HYPeripheralManager alloc] init];
        });
    }
    
    return _manager;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initSetting];
    }
    
    return self;
}

- (void)initSetting {
    self.automScan = YES;
    self.automReconnect = YES;
    self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
}

+ (instancetype)shareManagerDidUpdateStateHandle:(PeripheralStateUpdateHandle)completion {
    if (_manager) {     // 手动刷新状态
        [_manager centralManagerDidUpdateState:_manager.centralManager];
    }else {
        _manager = [HYPeripheralManager shareManager];
        _manager.stateCompletion = completion;
    }
    
    return _manager;
}

- (void)scanPeripheralWithServiceUUIDs:(NSArray <NSString *>*)uuids completion:(PeripheralScanCompletionHandle)completion {
    if (uuids.count) {
        NSMutableArray *array;
        if (uuids.count) {
            array = [NSMutableArray array];
            for (NSString *str in uuids) {
                [array addObject:[CBUUID UUIDWithString:str]];
            }
            _searchUUIDs = [array copy];
        }
    }
    
    [self.centralManager scanForPeripheralsWithServices:_searchUUIDs options:nil];
    /**
     *  本类自动scan传过来的回调都是nil,当不为nil时(在外部类中调用scan方法),应该更新
     */
    if (completion) {
        self.scanCompletion = completion;
    }
}

- (void)connectPeripheral:(HYPeripheral *)device completion:(PeripheralConnectCompletionHandle)completion {
    if (device.peripheral.state == CBPeripheralStateDisconnected) {
        [self.centralManager connectPeripheral:device.peripheral options:nil];
    }
    self.connectCompletion = completion;
}

- (void)cancelPeripheralConnection:(HYPeripheral *)device completion:(PeripheralConnectCompletionHandle)completion {
    _isManualDisconnect = YES;
    _disconnectPeripheral = device;
    [self.centralManager cancelPeripheralConnection:device.peripheral];
    self.disConnectCompletion = completion;
}

#pragma mark - 读取数据

- (void)readSNCodeData:(HYPeripheral *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:HYPeripheralDataTypeSNCode readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
    }];
}

- (void)readBatteryData:(HYPeripheral *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:HYPeripheralDataTypeBattery readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
        if ([value respondsToSelector:@selector(integerValue)]) {
            if ([value integerValue] < MinPower) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"电池电量低!" message:@"" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil];
                [alert show];
            }
        }
    }];
}

- (void)readTemperatureData:(HYPeripheral *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:HYPeripheralDataTypeTemperature readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
    }];
}


#pragma mark - CBCentralManagerDelegate

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    if (self.stateCompletion) {
        self.stateCompletion((HYPeripheralManagerState)central.state);
    }
    if (self.automScan) {
        [central scanForPeripheralsWithServices:_searchUUIDs options:nil];
    }
}

/**
 *  发现设备
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
    if ([peripheral.name hasPrefix:@"TMP"] == NO) {
        return;
    }
    NSLog(@"发现设备--->%@, %@", advertisementData, peripheral.identifier.UUIDString);
    NSMutableArray *ary = [NSMutableArray arrayWithArray:self.discoveredPeripherals];
    for (int i = 0; i < ary.count; i++) {
        HYPeripheral *device = ary[i];
        if ([device.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            [ary removeObject:device];
            break;
        }
    }
    
    HYPeripheral *device = [[HYPeripheral alloc] initWithPeripheral:peripheral];
    [ary addObject:device];
    _discoveredPeripherals = [ary copy];
    /**
     *  不管是用户手动扫描还是automScan,都用scanCompletion回调
     */
    if (self.scanCompletion) {
        self.scanCompletion(_discoveredPeripherals);
    }
}

/**
 *  已连接
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    NSMutableArray *discoverAry = [NSMutableArray arrayWithArray:self.discoveredPeripherals];
    NSMutableArray *connAry = [NSMutableArray arrayWithArray:self.connectedPeripherals];
    
    HYPeripheral *device;
    for (HYPeripheral *dvc in discoverAry) {
        if ([dvc.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            device = dvc;
            break;
        }
    }
    
    if (device) {
        [device readDataWithType:HYPeripheralDataTypeCheckNotify readValueCompletionHandle:^(id value, NSError *error) {
            [connAry addObject:device];
            [discoverAry removeObject:device];
            _discoveredPeripherals = [discoverAry copy];
            _connectedPeripherals = [connAry copy];
            
            _temperatureNotifyEnable = [value boolValue];
            if (self.connectCompletion) {
                self.connectCompletion(device, nil, error);
            }
        }];
    }
}

/**
 *  断开连接
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSMutableArray *connAry = [NSMutableArray arrayWithArray:self.connectedPeripherals];
    
    HYPeripheral *device;
    for (int i = 0; i < connAry.count; i++) {
        device = connAry[i];
        if ([device.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            [connAry removeObject:device];
            break;
        }
    }
    _connectedPeripherals = [connAry copy];
    
    /**
     *  当有disconnectCompletion就用disconnectCompletion回调, 否则用connectionCompletion回调
     */
    if (self.disConnectCompletion) {
        self.disConnectCompletion(device, error, nil);
    }else if (self.connectCompletion) {
        self.connectCompletion(device, error, nil);
    }

    if (_isManualDisconnect == YES) {
        if ([peripheral isEqual:_disconnectPeripheral.peripheral]) {
            _isManualDisconnect = NO;
        }
    }
    if (self.automReconnect && ![peripheral isEqual:_disconnectPeripheral.peripheral]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self performSelector:@selector(reconnect:) withObject:peripheral.identifier.UUIDString afterDelay:3.0];
        });
    }
    
    //peripheral对象 释放资源,防止内存泄漏
    [device readDataWithType:HYPeripheralDataTypeUnknown readValueCompletionHandle:nil];
    
    if (self.connectedPeripherals.count == 0) {
        self.connectCompletion = nil;
    }
    self.disConnectCompletion = nil;
    
    if (self.isAutomScan) {
        [self scanPeripheralWithServiceUUIDs:_searchUUIDs completion:nil];
    }
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"连接失败:%@", error);
    HYPeripheral *device = [[HYPeripheral alloc] initWithPeripheral:peripheral];
    
    if (self.connectCompletion) {
        self.connectCompletion(device, error, nil);
    }
}

#pragma mark - 

- (void)reconnect:(NSString *)UUIDString {
    for (HYPeripheral *device in self.discoveredPeripherals) {
        if ([device.peripheral.identifier.UUIDString isEqualToString:UUIDString]) {
            [self.centralManager connectPeripheral:device.peripheral options:nil];
            break;
        }
    }
    
    _isManualDisconnect = NO;
}

- (void)refreshDiscoverPeripheral {
    if (!_isRefreshing) {
        _isRefreshing = YES;
        NSMutableArray *array = [NSMutableArray array];
        for (HYPeripheral *device in self.discoveredPeripherals) {
            if (device.peripheral.state == CBPeripheralStateDisconnecting) {
                [array addObject:device];
            }
        }
        _discoveredPeripherals = [array copy];
        if (self.scanCompletion) {
            self.scanCompletion(_discoveredPeripherals);
        }
        
        [self.centralManager scanForPeripheralsWithServices:_searchUUIDs options:nil];
        [NSTimer scheduledTimerWithTimeInterval:RefreshTimeSpan target:self selector:@selector(resettingRefresh) userInfo:nil repeats:NO];
    }
}

- (void)resettingRefresh {
    _isRefreshing = NO;
}

- (void)reset {
    self.scanCompletion = nil;
    self.stateCompletion = nil;
    self.connectCompletion = nil;
    self.disConnectCompletion = nil;
}

- (BOOL)initWithTemperatureKey:(NSString *)key {
    BOOL isKey = false;
    NSString *key1 = nil;
    NSString *key2 = nil;
    if ([key length] == 40) {
        key1 = [key substringWithRange:NSMakeRange(20, 20)];
        NSString *sha1Str = [self sha1:key1];
        key2 = [sha1Str substringWithRange:NSMakeRange(0, 20)];
        NSString *allStr = [NSString stringWithFormat:@"%@%@",key2,key1];
        if ([key isEqualToString:allStr]) {
            isKey = true;
            
        } else {
            isKey = false;
        }
    } else {
        isKey = false;
    }
    return isKey;
}

- (NSString *)sha1:(NSString *)keyStr {
    NSString *str = [NSString stringWithFormat:@"%@%@",keyStr,@"ch.7Hb9.!ldT,Bb`EW!gwhG'yAObOt!W_S'1C=xGsl%ValJdYIiXK5Pj"];
    const char *cstr = [str cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:str.length];
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    CC_SHA1(data.bytes, (unsigned int)data.length, digest);
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    return output;
}

#pragma mark - getter

- (HYPeripheralManagerState)state {
    _state = (HYPeripheralManagerState)self.centralManager.state;
    return _state;
}


@end
