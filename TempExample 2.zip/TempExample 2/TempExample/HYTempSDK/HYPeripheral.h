//
//  HYPeripheral.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, HYPeripheralDataType) {
    HYPeripheralDataTypeCheckNotify,        // 检测体温数据是否自动推送
    HYPeripheralDataTypeBattery,            // 电池数据
    HYPeripheralDataTypeTemperature,        // 体温数据
    HYPeripheralDataTypeSNCode,             // SNCode
    HYPeripheralDataTypeUnknown,            // 其他
};

typedef void(^PeripheralReadValueCompletionHandle)(id value, NSError *error);

@interface HYPeripheral : NSObject

- (instancetype)init NS_UNAVAILABLE;

/**
 *  每个Peripheral对象对应一个peripheral
 */
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral;

/**
 *  Pointer to CoreBluetooth peripheral
 */
@property (nonatomic, strong, readonly) CBPeripheral *peripheral;

/**
 *  读取设备数据
 *
 *  @param completion 读取数据回调
 */
- (void)readDataWithType:(HYPeripheralDataType)type readValueCompletionHandle:(PeripheralReadValueCompletionHandle)completion;

@end
