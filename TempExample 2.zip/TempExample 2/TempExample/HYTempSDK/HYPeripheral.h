//
//  HYPeripheral.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, HYPeripheralDataType) {
    HYPeripheralDataTypeCheckNotify,
    HYPeripheralDataTypeBattery,
    HYPeripheralDataTypeTemperature,
    HYPeripheralDataTypeSNCode,
    HYPeripheralDataTypeUnknown,
};

typedef void(^PeripheralReadValueCompletionHandle)(id value, NSError *error);

@interface HYPeripheral : NSObject

- (instancetype)init NS_UNAVAILABLE;

/**
 *  每个Peripheral对象对应一个peripheral
 */
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral;
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral RSSI:(NSNumber *)rssi;

/**
 *  Pointer to CoreBluetooth peripheral
 */
@property (nonatomic, strong, readonly) CBPeripheral *peripheral;
@property (nonatomic, strong, readonly) NSNumber *RSSI;
@property (nonatomic, copy  , readonly) NSString *name;


/**
 *  读取设备数据
 *
 *  @param completion 读取数据回调
 */
- (void)readDataWithType:(HYPeripheralDataType)type readValueCompletionHandle:(PeripheralReadValueCompletionHandle)completion;

@end
