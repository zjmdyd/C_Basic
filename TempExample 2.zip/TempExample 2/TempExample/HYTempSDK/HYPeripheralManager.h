//
//  HYPeripheralManager.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  蓝牙的状态
 */
typedef NS_ENUM(NSUInteger, HYPeripheralManagerState) {
    HYPeripheralManagerStateUnknown = 0,
    HYPeripheralManagerStateResetting,
    HYPeripheralManagerStateUnsupported,
    HYPeripheralManagerStateUnauthorized,
    HYPeripheralManagerStatePoweredOff,
    HYPeripheralManagerStatePoweredOn,
};

@class HYPeripheral;

/**
 *  扫描回调方法
 */
typedef void(^PeripheralScanCompletionHandle)(NSArray *obj);

/**
 *  状态更新回调
 */
typedef void(^PeripheralStateUpdateHandle)(HYPeripheralManagerState state);

/**
 *  连接操作回调
 */
typedef void(^PeripheralConnectCompletionHandle)(HYPeripheral *obj, NSError *connectError, NSError *serviceException);

@interface HYPeripheralManager : NSObject

/**
 *  获取单例manager
 */
+ (instancetype)shareManager;

/**
 *  初始化SDK
 **/
- (BOOL)initWithTemperatureKey:(NSString *)key;

/**
 *  已发现的设备
 */
@property (nonatomic, strong, readonly) NSArray *discoveredPeripherals;

/**
 *  已连接的设备
 */
@property (nonatomic, strong, readonly) NSArray *connectedPeripherals;

/**
 *  判断当前连接的设备是否会主动推送体温数据,此属性需要设备连接之后才生效
 */
@property (nonatomic, readonly) BOOL temperatureNotifyEnable;

/**
 *  设备断开是否自动重连,默认为YES
 */
@property (nonatomic, getter=isAutomReconnect) BOOL automReconnect;

@property(nonatomic, readonly) HYPeripheralManagerState state;

/**
 *  manager状态更新, 在回调方法里面对不同的状态进行处理
 */
+ (instancetype)shareManagerDidUpdateStateHandle:(PeripheralStateUpdateHandle)completion;

/**
 *  扫描设备
 *  @param uuids      搜索包含服务特定服务uuid的设备, 当为nil时表示搜索所有附近蓝牙设备,数组元素为NSString类型
 *  @param completion 搜索设备结果返回的回调方法, 如UI刷新
 */
- (void)scanPeripheralWithServiceUUIDs:(NSArray <NSString *>*)uuids completion:(PeripheralScanCompletionHandle)completion;

/**
 *  连接设备
 *
 *  @param peripherals    需要连接的设备, 数组的元素是HYPeripheral对象类型
 *  @param completion 连接操作的回调,(HYPeripheral *obj, NSError *connectError, NSError *serviceException),当出现下面三种情况时会报serviceException:
 *  1. 当设备不主动推送体温数据时
 *  2. 当设备未搜索到服务时
 *  3. 当设备未搜索到特征时
 */
- (void)connectPeripheral:(HYPeripheral *)peripheral completion:(PeripheralConnectCompletionHandle)completion;

/**
 *  手动断开连接
 *
 *  @param peripherals    需要断开的设备, 数组的元素是HYPeripheral对象类型
 *  @param completion 断开连接后的回调
 */
- (void)cancelPeripheralConnection:(HYPeripheral *)peripheral completion:(PeripheralConnectCompletionHandle)completion;


/***********************************************************/
/***************	读取设备数据(须连接后方能读取)	************/
/***********************************************************/


/**
 *  读取设备电池电量，单位：mV，
 *  当电池电压发生变化时，设备会主动推送最新电池电压给APP，若电池电压低于2800mV，则APP需提示：设备电量不足；
 *  @param completion 若APP检测到设备有该特性，才能读取成功
 */
- (void)readBatteryData:(HYPeripheral *)peripheral completion:(void (^)(NSString *value, NSError *error))completion;

/**
 *  读取实时体温数据
 *  当设备不主动推送最新体温值给APP时，该方法只会读取一次体温数据；
 */
- (void)readTemperatureData:(HYPeripheral *)peripheral completion:(void (^)(NSString *value, NSError *error))completion;

/**
 *  读取设备SN码，
 *  设备支持APP实时读取SN码的操作，每台设备具有唯一的SN码；
 *  对于同一台设备，APP只需读取一次SN码；APP连接设备后，若发现更换了设备，则需重新读取SN码；
 *
 *  @param completion 若APP检测到设备有该特性，才能读取成功
 */
- (void)readSNCodeData:(HYPeripheral *)peripheral completion:(void (^)(NSString *value, NSError *error))completion;


/**
 *  刷新已发现的设备
 */
- (void)refreshDiscoverPeripheral;

/**
 *  重置,释放一些资源:因为本类的对象采用单例模式,所以当本类的功能完成时需要释放一些资源
 */
- (void)resetting;

#pragma mark -  待删

/**
 *  停止扫描
 */
- (void)stopScan;

/**
 *  设备断开之后是否自动执行搜索,默认为YES
 */
@property (nonatomic, getter=isAutomScan) BOOL automScan;

@end
