//
//  ZJBLEDeviceManager.m
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJBLEDeviceManager.h"

@interface ZJBLEDeviceManager ()<CBCentralManagerDelegate> {
    BOOL _isRefreshing;
    NSArray *_searchUUIDs;
}

@property (nonatomic, strong) CBCentralManager *centralManager;
@property (nonatomic, strong) BLEScanCompletionHandle scanCompletion;
@property (nonatomic, strong) BLEStateUpdateHandle stateCompletion;
@property (nonatomic, strong) BLEConnectCompletionHandle connectCompletion;
@property (nonatomic, strong) BLEConnectCompletionHandle disConnectCompletion;

@end

#define RefreshTimestamp 15
static ZJBLEDeviceManager *_manager = nil;

@implementation ZJBLEDeviceManager

@synthesize state = _state;

+ (instancetype)shareManager {
    if (!_manager) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _manager = [[ZJBLEDeviceManager alloc] init];
        });
    }
    
    return _manager;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initSetting];
    }
    
    return self;
}

- (void)initSetting {
    self.automScan = YES;
    self.automReconnect = YES;
    self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
}

+ (instancetype)shareManagerDidUpdateStateHandle:(BLEStateUpdateHandle)completion {
    if (_manager) {     // 手动刷新状态
        [_manager centralManagerDidUpdateState:_manager.centralManager];
    }else {
        _manager = [ZJBLEDeviceManager shareManager];
        _manager.stateCompletion = completion;
    }
    
    return _manager;
}

- (void)scanDeviceWithServiceUUIDs:(NSArray <NSString *>*)uuids completion:(BLEScanCompletionHandle)completion {
    if (uuids.count) {
        NSMutableArray *array;
        if (uuids.count) {
            array = [NSMutableArray array];
            for (NSString *str in uuids) {
                [array addObject:[CBUUID UUIDWithString:str]];
            }
            _searchUUIDs = [array copy];
        }
    }
    
    [self.centralManager scanForPeripheralsWithServices:_searchUUIDs options:nil];
    /**
     *  本类自动scan传过来的回调都是nil,当不为nil时(在外部类中调用scan方法),应该更新
     */
    if (completion) {
        self.scanCompletion = completion;
    }
}

- (void)connectBLEDevice:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion {
    if (device.peripheral.state == CBPeripheralStateDisconnected) {
        [self.centralManager connectPeripheral:device.peripheral options:nil];
    }
    self.connectCompletion = completion;
}

- (void)cancelBLEDeviceConnection:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion {
    [self.centralManager cancelPeripheralConnection:device.peripheral];
    self.disConnectCompletion = completion;
}

#pragma mark - 读取数据

- (void)readSNCodeData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:ZJBLEDeviceDataTypeSNCode readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
    }];
}

- (void)readBatteryData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:ZJBLEDeviceDataTypeBattery readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
    }];
}

- (void)readTemperatureData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion {
    [device readDataWithType:ZJBLEDeviceDataTypeTemperature readValueCompletionHandle:^(id value, NSError *error) {
        if (completion) {
            completion(value, error);
        }
    }];
}


#pragma mark - CBCentralManagerDelegate

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    if (self.stateCompletion) {
        self.stateCompletion((ZJBLEDeviceManagerState)central.state);
    }
    if (self.automScan) {
        [central scanForPeripheralsWithServices:_searchUUIDs options:nil];
    }
}

/**
 *  发现设备
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
    if ([peripheral.name hasPrefix:@"TMP"] == NO) {
        return;
    }
    NSLog(@"发现设备--->%@, %@", advertisementData, peripheral.identifier.UUIDString);
    NSMutableArray *ary = [NSMutableArray arrayWithArray:self.discoveredBLEDevices];
    for (int i = 0; i < ary.count; i++) {
        ZJBLEDevice *device = ary[i];
        if ([device.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            [ary removeObject:device];
            break;
        }
    }
    
    ZJBLEDevice *device = [[ZJBLEDevice alloc] initWithPeripheral:peripheral RSSI:RSSI];
    [ary addObject:device];
    _discoveredBLEDevices = [ary copy];
    /**
     *  不管是用户手动扫描还是automScan,都用scanCompletion回调
     */
    if (self.scanCompletion) {
        self.scanCompletion(_discoveredBLEDevices);
    }
}

/**
 *  已连接
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    NSMutableArray *discoverAry = [NSMutableArray arrayWithArray:self.discoveredBLEDevices];
    NSMutableArray *connAry = [NSMutableArray arrayWithArray:self.connectedBLEDevices];
    
    ZJBLEDevice *device;
    for (ZJBLEDevice *dvc in discoverAry) {
        if ([dvc.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            device = dvc;
            break;
        }
    }
    
    if (device) {
        [device readDataWithType:ZJBLEDeviceDataTypeCheckNotify readValueCompletionHandle:^(id value, NSError *error) {
            [connAry addObject:device];
            [discoverAry removeObject:device];
            _discoveredBLEDevices = [discoverAry copy];
            _connectedBLEDevices = [connAry copy];
            
            _temperatureNotifyEnable = [value boolValue];
            if (self.connectCompletion) {
                self.connectCompletion(device, nil, error);
            }
        }];
    }
}

/**
 *  断开连接
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSMutableArray *connAry = [NSMutableArray arrayWithArray:self.connectedBLEDevices];
    
    ZJBLEDevice *device;
    for (int i = 0; i < connAry.count; i++) {
        device = connAry[i];
        if ([device.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
            [connAry removeObject:device];
            break;
        }
    }
    _connectedBLEDevices = [connAry copy];
    
    /**
     *  当有disconnectCompletion就用disconnectCompletion回调, 否则用connectionCompletion回调
     */
    if (self.disConnectCompletion) {
        self.connectCompletion(device, error, nil);
    }else if (self.connectCompletion) {
        self.connectCompletion(device, error, nil);
    }
    
    if (self.isAutomScan) {
        [self scanDeviceWithServiceUUIDs:_searchUUIDs completion:nil];
    }
    
    if (self.automReconnect) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self performSelector:@selector(reconnect:) withObject:peripheral.identifier.UUIDString afterDelay:3.0];
        });
    }
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"连接失败:%@", error);
    ZJBLEDevice *device = [[ZJBLEDevice alloc] initWithPeripheral:peripheral];
    
    if (self.connectCompletion) {
        self.connectCompletion(device, error, nil);
    }
}

#pragma mark - 

- (void)reconnect:(NSString *)UUIDString {
    for (ZJBLEDevice *device in self.discoveredBLEDevices) {
        if ([device.peripheral.identifier.UUIDString isEqualToString:UUIDString]) {
            [self.centralManager connectPeripheral:device.peripheral options:nil];
            break;
        }
    }
}

- (void)refreshDiscoverDevice {
    if (!_isRefreshing) {
        _isRefreshing = YES;
        NSMutableArray *array = [NSMutableArray array];
        for (ZJBLEDevice *device in self.discoveredBLEDevices) {
            if (device.peripheral.state == CBPeripheralStateDisconnecting) {
                [array addObject:device];
            }
        }
        _discoveredBLEDevices = [array copy];
        if (self.scanCompletion) {
            self.scanCompletion(_discoveredBLEDevices);
        }
        [self.centralManager scanForPeripheralsWithServices:_searchUUIDs options:nil];
        [NSTimer scheduledTimerWithTimeInterval:RefreshTimestamp target:self selector:@selector(resettingRefresh) userInfo:nil repeats:NO];
    }
}

- (void)resettingRefresh {
    _isRefreshing = NO;
}

- (void)resetSetting {
    _discoveredBLEDevices = @[];
    self.scanCompletion = nil;
    self.stateCompletion = nil;
    self.connectCompletion = nil;
    self.disConnectCompletion = nil;
}

- (void)stopScan {
    self.scanCompletion = nil;
    [self.centralManager stopScan];
}

#pragma mark - getter

- (ZJBLEDeviceManagerState)state {
    _state = (ZJBLEDeviceManagerState)self.centralManager.state;
    return _state;
}


@end
