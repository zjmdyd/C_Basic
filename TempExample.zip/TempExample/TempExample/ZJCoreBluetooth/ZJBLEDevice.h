//
//  ZJBLEDevice.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, ZJBLEDeviceDataType) {
    ZJBLEDeviceDataTypeCheckNotify,
    ZJBLEDeviceDataTypeBattery,
    ZJBLEDeviceDataTypeTemperature,
    ZJBLEDeviceDataTypeSNCode,
    ZJBLEDeviceDataTypeUnknown,
};

typedef void(^BLEDeviceReadValueCompletionHandle)(id value, NSError *error);

@class ZJBLEDeviceManager;

@interface ZJBLEDevice : NSObject

- (instancetype)init NS_UNAVAILABLE;

/**
 *  每个BLEDevice对象对应一个peripheral
 */
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral;
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral RSSI:(NSNumber *)rssi;

/**
 *  Pointer to CoreBluetooth peripheral
 */
@property (nonatomic, strong, readonly) CBPeripheral *peripheral;
@property (nonatomic, strong, readonly) NSNumber *RSSI;
@property (nonatomic, copy  , readonly) NSString *name;


/**
 *  读取设备数据
 *
 *  @param completion 读取数据回调
 */
- (void)readDataWithType:(ZJBLEDeviceDataType)type readValueCompletionHandle:(BLEDeviceReadValueCompletionHandle)completion;

@end
