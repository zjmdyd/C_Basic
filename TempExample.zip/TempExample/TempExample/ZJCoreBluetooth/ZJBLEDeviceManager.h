//
//  ZJBLEDeviceManager.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZJBLEDevice.h"

/**
 *  蓝牙的状态
 */
typedef NS_ENUM(NSUInteger, ZJBLEDeviceManagerState) {
    ZJBLEDeviceManagerStateUnknown = 0,
    ZJBLEDeviceManagerStateResetting,
    ZJBLEDeviceManagerStateUnsupported,
    ZJBLEDeviceManagerStateUnauthorized,
    ZJBLEDeviceManagerStatePoweredOff,
    ZJBLEDeviceManagerStatePoweredOn,
};

/**
 *  扫描回调方法
 */
typedef void(^BLEScanCompletionHandle)(NSArray *obj);

/**
 *  状态更新回调
 */
typedef void(^BLEStateUpdateHandle)(ZJBLEDeviceManagerState sate);

/**
 *  连接操作回调
 */
typedef void(^BLEConnectCompletionHandle)(ZJBLEDevice *obj, NSError *connectError, NSError *serviceException);

@interface ZJBLEDeviceManager : NSObject

/**
 *  获取单例manager
 */
+ (instancetype)shareManager;

/**
 *  已发现的BLE设备
 */
@property (nonatomic, strong, readonly) NSArray *discoveredBLEDevices;

/**
 *  已连接的BLE设备
 */
@property (nonatomic, strong, readonly) NSArray *connectedBLEDevices;

/**
 *  判断当前连接的设备是否会主动推送体温数据,此属性需要设备连接之后才生效
 */
@property (nonatomic, readonly) BOOL temperatureNotifyEnable;

/**
 *  设备断开是否自动重连,默认为YES
 */
@property (nonatomic, getter=isAutomReconnect) BOOL automReconnect;

@property(nonatomic, readonly) ZJBLEDeviceManagerState state;

/**
 *  manager状态更新, 在回调方法里面对不同的状态进行处理
 */
+ (instancetype)shareManagerDidUpdateStateHandle:(BLEStateUpdateHandle)completion;

/**
 *  扫描设备
 *  @param uuids      搜索包含服务特定服务uuid的设备, 当为nil时表示搜索所有附近蓝牙设备,数组元素为NSString类型
 *  @param completion 搜索设备结果返回的回调方法, 如UI刷新
 */
- (void)scanDeviceWithServiceUUIDs:(NSArray <NSString *>*)uuids completion:(BLEScanCompletionHandle)completion;

/**
 *  连接设备
 *
 *  @param devices    需要连接的设备, 数组的元素是ZJBLEDevice对象类型
 *  @param completion 连接操作的回调,(ZJBLEDevice *obj, NSError *error),
 */
- (void)connectBLEDevice:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion;

/**
 *  手动断开连接
 *
 *  @param devices    需要断开的设备, 数组的元素是ZJBLEDevice对象类型
 *  @param completion 断开连接后的回调,(ZJBLEDevice *obj, NSError *connectError, NSError *serviceException),当出现下面三种情况时会报serviceException:
 *  1. 当设备不主动推送体温数据时
 *  2. 当设备未搜索到服务时
 *  3. 当设备未搜索到特征时
 */
- (void)cancelBLEDeviceConnection:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion;


/***********************************************************/
/***************	读取设备数据(须连接后方能读取)	************/
/***********************************************************/


/**
 *  读取设备电池电量，单位：mV，
 *  当电池电压发生变化时，设备会主动推送最新电池电压给APP，若电池电压低于2800mV，则APP需提示：设备电量不足；
 *  @param completion 若APP检测到设备有该特性，才能读取成功
 */
- (void)readBatteryData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion;

/**
 *  读取实时体温数据
 *  当设备不主动推送最新体温值给APP时，该方法只会读取一次体温数据；
 */
- (void)readTemperatureData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion;

/**
 *  读取设备SN码，
 *  设备支持APP实时读取SN码的操作，每台设备具有唯一的SN码；
 *  对于同一台设备，APP只需读取一次SN码；APP连接设备后，若发现更换了设备，则需重新读取SN码；
 *
 *  @param completion 若APP检测到设备有该特性，才能读取成功
 */
- (void)readSNCodeData:(ZJBLEDevice *)device completion:(void (^)(NSString *value, NSError *error))completion;


/**
 *  刷新已发现的设备
 */
- (void)refreshDiscoverDevice;

/**
 *  释放资源:因为本类的对象采用单例模式,所以当本类的功能完成时需要释放一些资源
 */
- (void)resetSetting;

#pragma mark -  待删

/**
 *  停止扫描
 */
- (void)stopScan;

/**
 *  设备断开之后是否自动执行搜索,默认为YES
 */
@property (nonatomic, getter=isAutomScan) BOOL automScan;

@end
