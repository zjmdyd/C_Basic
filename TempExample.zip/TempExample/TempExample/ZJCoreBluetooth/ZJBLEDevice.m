//
//  ZJBLEDevice.m
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJBLEDevice.h"
#import "ZJBLEDeviceManager.h"

@interface CBCharacteristic (ZJCBCharacteristic)

- (BOOL)isSNCodeCharacteristic;
- (BOOL)isTemperatureCharacteristic;
- (BOOL)isBatteryCharacteristic;

@end

@implementation CBCharacteristic (ZJCBCharacteristic)

- (BOOL)isBatteryCharacteristic {
    if ([self.UUID.UUIDString isEqualToString:@"FFF6"]) {
        return YES;
    }
    return NO;
}

- (BOOL)isTemperatureCharacteristic {
    if ([self.UUID.UUIDString isEqualToString:@"FFF1"]) {
        return YES;
    }
    return NO;
}

- (BOOL)isSNCodeCharacteristic {
    if ([self.UUID.UUIDString isEqualToString:@"FFF9"]) {
        return YES;
    }
    return NO;
}

@end

@interface NSString (ZJString)

+ (NSString *)ToHex:(uint16_t)tmpid;
- (NSString *)hexTobinaryString;
- (NSString *)binaryToHexString;
- (NSString *)invertString;

@end

@implementation NSString (ZJString)

/**
 *  十进制转十六进制
 */
+ (NSString *)ToHex:(uint16_t)tmpid {
    NSString *nLetterValue;
    NSString *str = @"";
    uint16_t ttmpig;
    for (int i = 0; i < 9; i++) {
        ttmpig = tmpid % 16; // 256 % 16 = 0;  --> 0 --> 0
        tmpid = tmpid / 16;  // 256 / 16 = 16; --> 1 --> 0
        switch (ttmpig) {
            case 10:
                nLetterValue = @"A"; break;
            case 11:
                nLetterValue = @"B"; break;
            case 12:
                nLetterValue = @"C"; break;
            case 13:
                nLetterValue = @"D"; break;
            case 14:
                nLetterValue = @"E"; break;
            case 15:
                nLetterValue = @"F"; break;
            default:
                nLetterValue = [NSString stringWithFormat:@"%u", ttmpig];    //0 ----> 0 ----> 1
        }
        str = [nLetterValue stringByAppendingString:str];   // 0 ----> 00 ----> 100
        if (tmpid == 0) {
            break;
        }
    }
    return str;
}

/**
 *  十六进制转二进制
 */
- (NSString *)hexTobinaryString {
    NSString *originString = [self copy];
    if (originString.length>2) {
        NSString *prefix = [self substringWithRange:NSMakeRange(0, 2)];
        if ([[prefix uppercaseString] isEqualToString:@"0X"]) {
            originString = [originString substringWithRange:NSMakeRange(2, originString.length-2)];
        }
    }
    
    NSMutableDictionary *hexDic = [[NSMutableDictionary alloc] init];
    hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    NSArray *keys = @[@"A", @"B", @"C", @"D", @"E", @"F"];
    NSArray *values = @[@"0000", @"0001", @"0010", @"0011", @"0100", @"0101", @"0110", @"0111", @"1000", @"1001", @"1010", @"1011", @"1100", @"1101", @"1110", @"1111"];
    for (int i = 0; i < values.count; i++) {
        [hexDic setObject:values[i] forKey:[NSString stringWithFormat:@"%@", i<10?@(i):keys[i-10]]];
    }
    
    NSMutableString *binaryString = [[NSMutableString alloc] init];
    for (int i = 0; i < originString.length; i++) {
        NSString *key = [originString substringWithRange:NSMakeRange(i, 1)];       // 取出16进制里面的每一位数对应的key
        NSString *value = [NSString stringWithFormat:@"%@", [hexDic objectForKey:[key uppercaseString]]];
        binaryString = [NSString stringWithFormat:@"%@%@", binaryString, value].mutableCopy;
    }
    
    return binaryString;
}

/**
 *  二进制转十六进制
 */
- (NSString *)binaryToHexString {
    NSMutableDictionary *hexDic = [[NSMutableDictionary alloc] init];
    hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    NSArray *keys = @[@"A", @"B", @"C", @"D", @"E", @"F"];
    NSArray *values = @[@"0000", @"0001", @"0010", @"0011", @"0100", @"0101", @"0110", @"0111", @"1000", @"1001", @"1010", @"1011", @"1100", @"1101", @"1110", @"1111"];
    for (int i = 0; i < values.count; i++) {
        [hexDic setObject:values[i] forKey:[NSString stringWithFormat:@"%@", i<10?@(i):keys[i-10]]];
    }
    
    NSMutableString *HexString = [[NSMutableString alloc] init];
    for (int i = 0; i < self.length; i+=4) {
        NSString *value = [self substringWithRange:NSMakeRange(i, 4)];       // 取出二进制里面的每4位数对应的value
        for (NSString *key in hexDic.allKeys) {
            if ([[hexDic objectForKey:key] isEqualToString:value]) {
                [HexString appendString:key];
                break;
            }
        }
    }
    
    return HexString;
}

/**
 *  字符串翻转
 */
- (NSString *)invertString {
    NSMutableString *s = [NSMutableString string];
    for (NSUInteger i = self.length; i > 0; i--) {
        [s appendString:[self substringWithRange:NSMakeRange(i-1, 1)]];
    }
    return s;
}
/**
 *  将二进制数据转换成十六进制字符串
 *
 *  @param data 二进制数据
 *
 *  @return 十六进制字符串
 */
+ (NSString *)data2Hex:(NSData *)data {
    if (!data) {
        return nil;
    }
    Byte *bytes = (Byte *)[data bytes];
    NSMutableString *str = [NSMutableString stringWithCapacity:data.length * 2];
    for (int i=0; i < data.length; i++){
        [str appendFormat:@"%0x", bytes[i]];
    }
    return str;
}

/**
 *  二进制字符串取反
 */
- (NSString *)binaryOppositionString {
    NSMutableString *str = [NSMutableString string];
    for (int i = 0; i < self.length; i++) {
        NSRange range = NSMakeRange(i, 1);
        NSUInteger value = [self substringWithRange:range].integerValue;
        [str appendString:[NSString stringWithFormat:@"%zd", (value+1)%2]];
    }
    return str;
}

@end

@interface ZJBLEDevice () <CBPeripheralDelegate>

@property (nonatomic, strong) BLEDeviceReadValueCompletionHandle batteryReadValueCompletion;
@property (nonatomic, strong) BLEDeviceReadValueCompletionHandle temperatureReadValueCompletion;
@property (nonatomic, strong) BLEDeviceReadValueCompletionHandle snCodeReadValueCompletion;
@property (nonatomic, strong) BLEDeviceReadValueCompletionHandle unknowTypeReadValueCompletion; // 一次性请求的回调
@property (nonatomic, strong) BLEDeviceReadValueCompletionHandle checkNotifyReadValueCompletion;

@end

NSString *const SERVICE_UUID = @"FFF0";

@implementation ZJBLEDevice

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral {
    self = [super init];
    if (self) {
        _peripheral = peripheral;
        _peripheral.delegate = self;
        _name = peripheral.name;
    }
    
    return self;
}

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral RSSI:(NSNumber *)rssi {
    self = [super init];
    if (self) {
        _peripheral = peripheral;
        _peripheral.delegate = self;
        _name = peripheral.name;
        _RSSI = rssi;
    }
    
    return self;
}

#pragma mark - method

- (void)readDataWithType:(ZJBLEDeviceDataType)type readValueCompletionHandle:(BLEDeviceReadValueCompletionHandle)completion {
    if (self.peripheral.state == CBPeripheralStateConnected) {
        if (type == ZJBLEDeviceDataTypeCheckNotify) {
            self.checkNotifyReadValueCompletion = completion;
            [self.peripheral discoverServices:@[[CBUUID UUIDWithString:SERVICE_UUID]]];
        }else if (type == ZJBLEDeviceDataTypeBattery) {
            self.batteryReadValueCompletion = completion;
        }else if (type == ZJBLEDeviceDataTypeTemperature) {
            self.temperatureReadValueCompletion = completion;
        }else if (type == ZJBLEDeviceDataTypeSNCode) {
            self.snCodeReadValueCompletion = completion;
        }else {
            self.unknowTypeReadValueCompletion = completion;
        }
        
        if (type >= ZJBLEDeviceDataTypeBattery && type < ZJBLEDeviceDataTypeUnknown) {
            [self readDataWithType:type];
        }
    }else {
        [self throwException:@"设备未连接" code:CBErrorNotConnected handle:completion];
    }
}

- (void)readDataWithType:(ZJBLEDeviceDataType)type {
    for (CBService *s in self.peripheral.services) {
        if ([s.UUID.UUIDString isEqualToString:SERVICE_UUID]) {
            for (CBCharacteristic *c in s.characteristics) {
                BOOL b = (type == ZJBLEDeviceDataTypeBattery && c.isBatteryCharacteristic) || (type == ZJBLEDeviceDataTypeTemperature && c.isTemperatureCharacteristic) || (type == ZJBLEDeviceDataTypeSNCode && c.isSNCodeCharacteristic);
                if (type == ZJBLEDeviceDataTypeTemperature) {
                    b = b && !c.isNotifying;
                }
                if (b) {
                    [self.peripheral readValueForCharacteristic:c];
                    break;
                }
            }
            break;
        }
    }
}


- (void)throwException:(NSString *)exception code:(NSInteger)code handle:(BLEDeviceReadValueCompletionHandle)completion {
    if (completion) {
        completion(@(NO), [NSError errorWithDomain:CBATTErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey:exception?:@""}]);
    }
}

#pragma mark - CBPeripheralDelegate

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(nullable NSError *)error {
    NSLog(@"-->services = %@", peripheral.services);
    
    if (peripheral.services.count) {
        for (CBService *s in peripheral.services) {
            [peripheral discoverCharacteristics:nil forService:s];
        }
    }else {
        [self throwException:@"未搜索到服务." code:CBATTErrorRequestNotSupported handle:self.checkNotifyReadValueCompletion];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    NSLog(@"-->characteristics = %@", service.characteristics);
    
    BOOL hasTemperatureCharacteristic = NO;
    for (CBCharacteristic *c in service.characteristics) {
        [peripheral setNotifyValue:YES forCharacteristic:c];
        if (c.isTemperatureCharacteristic) {
            hasTemperatureCharacteristic = YES;
        }
    }
    
    if (!hasTemperatureCharacteristic) {
        [self throwException:@"未搜索到特性." code:CBATTErrorRequestNotSupported handle:self.checkNotifyReadValueCompletion];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error {
    NSLog(@"didUpdateValueForCharacteristic = %@", characteristic);
    
    if (characteristic.isSNCodeCharacteristic) {
        if (self.snCodeReadValueCompletion) {
            NSString *str = characteristic.value.description;
            if (str.length > 1) {
                str = [str substringWithRange:NSMakeRange(1, str.length-2)];
            }
            unsigned long j = strtoul([str UTF8String] , 0, 16);
            self.snCodeReadValueCompletion(@(j), error);
        }
    }else if (characteristic.isBatteryCharacteristic) {
        if (self.batteryReadValueCompletion) {
            NSString *str = characteristic.value.description;
            if (str.length > 1) {
                str = [str substringWithRange:NSMakeRange(1, str.length-2)];
            }
            unsigned long j = strtoul([str UTF8String] , 0, 16);
            self.batteryReadValueCompletion(@(j), error);
        }
    }else if (characteristic.isTemperatureCharacteristic) {
        NSMutableString *str = [NSMutableString string];
        Byte *bytes = (Byte *)characteristic.value.bytes;
        for (int i = 0; i < characteristic.value.length; i++) {
            NSString *hexStr = [NSString ToHex:bytes[i]];           // 十进制  --> 十六进制
            NSString *binaryStr = hexStr.hexTobinaryString;         // 十六进制 --> 二进制
            NSString *invertStr = binaryStr.invertString;           // 二进制翻转
            [str insertString:invertStr atIndex:0];
        }
        NSString *result = str.binaryOppositionString;              // 二进制取反
        NSString *hexString = result.binaryToHexString;             // 二进制 --> 十六进制
        unsigned long j = strtoul(hexString.UTF8String , 0, 16);    // 十六进制 ---> 十进制
        
        if (self.temperatureReadValueCompletion) {
            self.temperatureReadValueCompletion( @(j), error);
        }
    }else {
        if (self.unknowTypeReadValueCompletion) {
            self.unknowTypeReadValueCompletion(characteristic.value, error);
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error {
    NSLog(@"didUpdateNotificationStateForCharacteristic = %@", characteristic);
    if (characteristic.isTemperatureCharacteristic) {
        if (self.checkNotifyReadValueCompletion) {
            self.checkNotifyReadValueCompletion(@(characteristic.isNotifying), error);
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    NSLog(@"-->didWriteValueForCharacteristic = %@", characteristic);
    
}

@end
