//
//  ViewController.m
//  TempExample
//
//  Created by ZJ on 9/7/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ViewController.h"
#import "ZJCoreBluetooth/ZJBLETool.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, weak) ZJBLEDeviceManager *bleManager;

@end

static NSString *TitleCell = @"cell";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initSettiing];
}

- (void)initSettiing {
    self.title = @"蓝牙列表";
    self.tableView.tableFooterView = [UIView new];
    
    self.bleManager = [ZJBLEDeviceManager shareManagerDidUpdateStateHandle:^(ZJBLEDeviceManagerState sate) {
        
    }];
    [[ZJBLEDeviceManager shareManager] scanDeviceWithServiceUUIDs:nil completion:^(id obj) {
        if (obj) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
    }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        NSLog(@"count0 = %zd", self.bleManager.discoveredBLEDevices.count);
        return self.bleManager.discoveredBLEDevices.count;
    }
    return self.bleManager.connectedBLEDevices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TitleCell];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:TitleCell];
    }
    NSLog(@"count1 = %zd", self.bleManager.discoveredBLEDevices.count);

    ZJBLEDevice *device;
    if (indexPath.section == 0) {
        device = self.bleManager.discoveredBLEDevices[indexPath.row];
    }else {
        device = self.bleManager.connectedBLEDevices[indexPath.row];
    }
    
    cell.textLabel.text = device.name;
    cell.detailTextLabel.text = device.RSSI.stringValue;
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        ZJBLEDevice *device = self.bleManager.discoveredBLEDevices[indexPath.row];
        [self.bleManager connectBLEDevice:device completion:^(ZJBLEDevice *obj, NSError *connectError, NSError *serviceException) {
            NSLog(@"connectError = %@, %@", connectError, serviceException);

            if (!connectError || [connectError isKindOfClass:[NSNull class]]) {
                [self.bleManager readSNCodeData:device completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                }];
                [self.bleManager readBatteryData:device completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                }];
                [self.bleManager readTemperatureData:device completion:^(NSString *value, NSError *error) {
                    NSLog(@"value = %@, %@", value, error);
                }];
            }else {
                NSLog(@"连接失败");
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return @"已发现";
    }
    
    return @"已连接";
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self.bleManager refreshDiscoverDevice];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
